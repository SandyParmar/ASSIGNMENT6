from tkinter import *

# Create the main application window
root = Tk()
root.title("Simple Calculator")
root.geometry("400x400")
root.resizable(False, False)

# Entry widget to display input and result
entry = Entry(root, width=16, font=("Arial", 24), borderwidth=5, justify="right")
entry.grid(row=0, column=0, columnspan=4, pady=10, padx=10)

# Global results string
results = ""


def press(num):
    global results
    results += str(num)
    entry.delete(0, END)
    entry.insert(END, results)


def clear():
    global results
    results = ""
    entry.delete(0, END)


def calculate():
    global results
    try:
        result = str(eval(results))
        entry.delete(0, END)
        entry.insert(END, result)
        results = result
    except:
        entry.delete(0, END)
        entry.insert(END, "Error")
        results = ""


# Button layout
buttons = [
    ("7", 1, 0),
    ("8", 1, 1),
    ("9", 1, 2),
    ("/", 1, 3),
    ("4", 2, 0),
    ("5", 2, 1),
    ("6", 2, 2),
    ("*", 2, 3),
    ("1", 3, 0),
    ("2", 3, 1),
    ("3", 3, 2),
    ("-", 3, 3),
    ("0", 4, 0),
    (".", 4, 1),
    ("+", 4, 2),
    ("=", 4, 3),
    ("Clear", 5, 0),
]

# Create buttons dynamically
for text, row, col in buttons:
    if text == "=":
        Button(root, text=text, width=5, height=2, command=calculate).grid(
            row=row, column=col, padx=5, pady=5
        )
    elif text == "Clear":
        Button(root, text=text, width=23, height=2, command=clear).grid(
            row=row, column=col, columnspan=4, padx=5, pady=5
        )
    else:
        Button(
            root, text=text, width=5, height=2, command=lambda t=text: press(t)
        ).grid(row=row, column=col, padx=0, pady=0)

# Start the GUI event loop
root.mainloop()
