from tkinter import *

root = Tk()
root.title("Simple Calculator")
root.geometry("400x400")
root.resizable(False, False)

entry = Entry(root, width=16, font=("Arial", 24), borderwidth=5, justify="right")
entry.grid(row=0, column=0, columnspan=4, pady=10, padx=10)

current_input = ""
operator = ""
operand1 = ""
operand2 = ""


def press(value):
    global current_input
    current_input += str(value)
    entry.delete(0, END)
    entry.insert(END, current_input)


def clear():
    global current_input, operator, operand1, operand2
    current_input = ""
    operator = ""
    operand1 = ""
    operand2 = ""
    entry.delete(0, END)


def calculate():
    global current_input, operator, operand1, operand2

    for op in ["+", "-", "*", "/"]:
        if op in current_input:
            parts = current_input.split(op)
            if len(parts) == 2:
                operand1, operand2 = parts
                operator = op
                break

    try:
        num1 = float(operand1)
        num2 = float(operand2)

        if operator == "+":
            result = num1 + num2
        elif operator == "-":
            result = num1 - num2
        elif operator == "*":
            result = num1 * num2
        elif operator == "/":
            if num2 == 0:
                raise ZeroDivisionError
            result = num1 / num2
        else:
            result = "Error"

        entry.delete(0, END)
        entry.insert(END, str(result))
        current_input = str(result)

    except ZeroDivisionError:
        entry.delete(0, END)
        entry.insert(END, "Div by 0")
        current_input = ""
    except:
        entry.delete(0, END)
        entry.insert(END, "Error")
        current_input = ""


buttons = [
    ("7", 1, 0),
    ("8", 1, 1),
    ("9", 1, 2),
    ("/", 1, 3),
    ("4", 2, 0),
    ("5", 2, 1),
    ("6", 2, 2),
    ("*", 2, 3),
    ("1", 3, 0),
    ("2", 3, 1),
    ("3", 3, 2),
    ("-", 3, 3),
    ("0", 4, 0),
    (".", 4, 1),
    ("+", 4, 2),
    ("=", 4, 3),
    ("Clear", 5, 0),
]

for text, row, col in buttons:
    if text == "=":
        Button(root, text=text, width=5, height=2, command=calculate).grid(
            row=row, column=col, padx=5, pady=5
        )
    elif text == "Clear":
        Button(root, text=text, width=23, height=2, command=clear).grid(
            row=row, column=col, columnspan=4, padx=5, pady=5
        )
    else:
        Button(
            root, text=text, width=5, height=2, command=lambda t=text: press(t)
        ).grid(row=row, column=col, padx=0, pady=0)

root.mainloop()
